package com.bodyrecomp.tracker

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scheduleAllReminders()
        else Toast.makeText(this, "Notifications are disabled. Enable them in Settings to receive reminders.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AppBridge(this), "NativeReminders")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
        createNotificationChannel()
        askNotificationPermissionAndSchedule()
    }

    private fun askNotificationPermissionAndSchedule() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else scheduleAllReminders()
    }

    private fun scheduleAllReminders() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                Toast.makeText(this, "For on-time reminders, allow Alarms & reminders in the next screen.", Toast.LENGTH_LONG).show()
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } catch (_: Exception) { }
                return
            }
        }
        ReminderScheduler.scheduleAll(this)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(ReminderReceiver.CHANNEL_ID, "Fitness and supplement reminders", android.app.NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Scheduled reminders for your daily Body Recomp Tracker routine"
            (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).createNotificationChannel(channel)
        }
    }

    inner class AppBridge(private val context: Context) {
        @JavascriptInterface fun scheduleReminders() { runOnUiThread { askNotificationPermissionAndSchedule(); Toast.makeText(context, "Daily reminders are being scheduled", Toast.LENGTH_SHORT).show() } }
        @JavascriptInterface fun stopReminders() { ReminderScheduler.cancelAll(context); Toast.makeText(context, "Daily reminders cancelled", Toast.LENGTH_SHORT).show() }
    }
}
