package com.bodyrecomp.tracker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object ReminderScheduler {
    data class Reminder(val id: Int, val hour: Int, val minute: Int, val title: String, val body: String)
    val reminders = listOf(
        Reminder(1001, 2, 55, "Pro Test reminder", "Check your current NPL label and only take the dose it directs. Do not double-dose."),
        Reminder(1002, 3, 15, "Workout time", "Start your warm-up and follow today's workout plan."),
        Reminder(1003, 4, 15, "Creatine reminder", "Take your usual daily serving as directed on the product label, mixed with water."),
        Reminder(1004, 4, 30, "Whey isolate reminder", "Use a serving mixed with water if needed to meet your daily protein target.")
    )

    fun scheduleAll(context: Context) { reminders.forEach { schedule(context, it) } }
    fun schedule(context: Context, reminder: Reminder) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("id", reminder.id); putExtra("title", reminder.title); putExtra("body", reminder.body)
        }
        val pi = PendingIntent.getBroadcast(context, reminder.id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, reminder.hour); set(Calendar.MINUTE, reminder.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        else am.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
    fun scheduleNext(context: Context, id: Int) { reminders.firstOrNull { it.id == id }?.let { schedule(context, it) } }
    fun cancelAll(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        reminders.forEach { r ->
            val pi = PendingIntent.getBroadcast(context, r.id, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            am.cancel(pi); pi.cancel()
        }
    }
}
