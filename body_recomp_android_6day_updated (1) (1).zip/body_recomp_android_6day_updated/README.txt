BODY RECOMP TRACKER — ANDROID APK PROJECT

This archive is the complete Android project. Its contents (including the hidden .github folder) must be uploaded directly into the ROOT of a GitHub repository.

WHAT IS INCLUDED
- Existing Body Recomp Tracker HTML app and its current workout, training/rest-day, habit, supplement, water and protein tracking screens.
- Native Android WebView wrapper.
- Native Android daily reminder scheduling and notification receiver.
- Reboot/time-change reminder rescheduling.
- GitHub Actions workflow to build and upload a debug APK.

BUILD REQUIREMENTS
The GitHub workflow installs Java 17, Android SDK platform 35/build-tools 35.0.0 and Gradle 8.9. It then runs a clean Android debug build and uploads the APK as an artifact. The app build file explicitly includes the AndroidX Activity and Core dependencies required by the Kotlin source and sets Java/Kotlin to JVM 17.

UPLOAD STEPS
1. Extract this ZIP.
2. In the GitHub repository, upload ALL CONTENTS of the extracted folder directly to the repository root. Do not upload the enclosing folder as one nested folder. Make sure the hidden .github/workflows/build-apk.yml file is included. If GitHub's phone uploader hides .github, use GitHub Desktop or a computer/browser that can upload hidden folders.
3. Commit the files to the main or master branch.
4. Open the repository's Actions tab and select "Build Android APK". It should start automatically after the commit. If not, select "Run workflow".
5. Wait for the run to finish. A green check means the build succeeded. Open the run and download the "Body-Recomp-Tracker-APK" artifact. Extract it to get app-debug.apk.
6. Transfer app-debug.apk to the Samsung phone and install it. Android may ask you to allow installation from that source.
7. Open the app and grant notification permission. If prompted, allow Alarms & reminders. For reliable delivery, check Samsung battery settings and allow the app to run without restrictive battery optimisation.

IMPORTANT BUILD STATUS
The project files and workflow have been checked locally for archive integrity and required build configuration. A successful APK build cannot be truthfully guaranteed until GitHub Actions actually runs the build; the green workflow result is the confirmation. If the run fails, send the red run's error log/screenshot so the exact failure can be corrected rather than repeating upload steps.

REMINDERS (PHONE LOCAL TIME)
02:55 — Pro Test label-check reminder only; follow the current product label and do not double-dose.
03:15 — Workout warm-up reminder.
04:15 — Creatine reminder; follow the product label.
04:30 — Whey reminder if needed to meet protein target.

DATA AND PRIVACY
Tracker entries are stored locally in the app's WebView storage on the phone. No server or account sync is configured. Clearing app data or uninstalling the app may erase locally stored entries.

This workflow builds a debug APK. It is suitable for installing on your own device but is not a Play Store release package.
